"use client"

import Component from "../eisenhower-matrix"

export default function Page() {
  return <Component />
}
